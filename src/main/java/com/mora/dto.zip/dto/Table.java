package com.mora.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Table {

    String product;
    int salaryRangeMin;
    int salaryRangeMax;
    int maxOverallDTI;
    int maxInternalDTI;

}
