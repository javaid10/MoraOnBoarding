package com.mora.dto;

import lombok.Data;

@Data
public class Default {

    String DF_PRD;
    String DF_CUB;
    String DF_STAT;
}
