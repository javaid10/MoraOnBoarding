package com.mora.dto;

import lombok.Data;

@Data
public class Judgment {

    String EJ_SETTLE_DATE;
}
