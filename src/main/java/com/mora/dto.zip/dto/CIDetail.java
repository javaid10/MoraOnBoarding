package com.mora.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CIDetail {

    String CI_PRD;
    String CI_STATUS;
    String CI_CRDTR;
    String CI_FRQ;
    String CI_INSTL;
    String CI_SUMMRY;

}
