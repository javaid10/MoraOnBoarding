package com.mora.dto;

import lombok.Data;

@Data
public class Employer {

    String ENMA;
}
