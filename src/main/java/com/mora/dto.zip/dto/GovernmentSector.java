package com.mora.dto;

import lombok.Data;

@Data
public class GovernmentSector {

    public PersonalInfo personalInfo;
    public BankInfo bankInfo;
    public EmployerInfo employerInfo;
    public EmploymentInfo employmentInfo;
    public PayslipInfo payslipInfo;

    @Data
    public static class BankInfo {

        String bankCode;
        String bankName;
        String accountNumber;

    }

    @Data
    public static class EmployerInfo {

        public String agencyCode;
        public String agencyName;

    }


    @Data
    public static class EmploymentInfo {

        String agencyEmploymentDate;
        String employeeJobNumber;
        String employeeJobTitle;

    }

    @Data
    public static class PayslipInfo {

        String payMonth;
        String totalAllownces;
        String basicSalary;
        String totalDeductions;
        String netSalary;

    }


    @Data
    public static class PersonalInfo {

        String employeeNameAr;
        String employeeNameEn;

    }


	public Object getEmploymentInfo() {
		// TODO Auto-generated method stub
		return null;
	}
}
