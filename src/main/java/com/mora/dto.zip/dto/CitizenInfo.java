package com.mora.dto;

import lombok.Data;

@Data
public class CitizenInfo {

    String dateOfBirthG;
    String dateOfBirthH;
	public String getDateOfBirthG() {
		// TODO Auto-generated method stub
		return null;
	}

}
