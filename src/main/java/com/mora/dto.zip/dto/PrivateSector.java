package com.mora.dto;

import lombok.Data;

@Data
public class PrivateSector {

    String otherAllowance;
    String establishmentActivity;
    String workingMonths;
    String fullName;
    String employerName;
    String housingAllowance;
    String basicWage;
    String employmentStatus;
    String dateOfJoining;
    String salaryStartingDate;

}
