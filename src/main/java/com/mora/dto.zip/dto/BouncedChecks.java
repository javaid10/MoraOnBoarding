package com.mora.dto;

import lombok.Data;

@Data
public class BouncedChecks {

    String BC_SETTLE_DATE;
}
